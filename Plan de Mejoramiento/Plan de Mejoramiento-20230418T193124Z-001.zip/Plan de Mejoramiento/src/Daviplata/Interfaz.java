package Daviplata;
    public interface Interfaz {
        boolean loguearse(String usuario, String contraseña);
        void cerrarSesion();
    }


